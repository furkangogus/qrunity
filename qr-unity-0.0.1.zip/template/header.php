
<div class="bg-primary position-relative">
  <div class="overlay-gradient"></div>
  <div class="container position-relative">
  	<div class="row py-5">
    	<div class="col">
      <img src="/logo.png" alt="logo" class="logo" width="160" height="160" />
        <h1 class="display-1">QR Unity</h1>
          <p>En iyi ücretsiz ontheWeb QR Code oluşturucusu.</p>
        <?php //<p><a href="#" class="btn btn-primary btn-lg shadow" role="button">Learn more &raquo;</a></p>?>
    </div>
    </div>
  </div>
</div>